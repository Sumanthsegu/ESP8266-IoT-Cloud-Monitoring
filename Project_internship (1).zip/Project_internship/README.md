# IoT Backend Project

## Description
This project is a complete IoT pipeline using:
- ESP8266
- DHT11 Sensor
- Node.js Backend
- MongoDB
- InfluxDB
- Render Deployment
- Real-time Dashboard

## Features
- Real-time sensor monitoring
- User authentication
- Device mapping
- Cloud data storage
- Dashboard visualization
- Temperature and humidity graphs

## Technologies Used
- ESP8266
- Arduino IDE
- Express.js
- MongoDB Atlas
- InfluxDB Cloud
- Chart.js
- Render

## Run Project

Install dependencies:

```bash
npm install