#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

const char* ssid = "SUMANTH";
const char* password = "asdfghjkl";

const char* host = "iot-backend-atfp.onrender.com";

String deviceId = "esp001";

void setup() {

  Serial.begin(115200);
  delay(1000);

  dht.begin();

  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
}

void loop() {

  // Reconnect WiFi if disconnected
  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("WiFi disconnected");
    WiFi.begin(ssid, password);

    while (WiFi.status() != WL_CONNECTED) {
      delay(500);
      Serial.print(".");
    }

    Serial.println("\nWiFi Reconnected");
  }

  delay(2000);

  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read DHT11");
    delay(2000);
    return;
  }

  Serial.print("Temp: ");
  Serial.println(temperature);

  Serial.print("Humidity: ");
  Serial.println(humidity);

  // HTTPS client
  WiFiClientSecure client;

  // Ignore SSL certificate validation
  client.setInsecure();

  Serial.println("Connecting to backend...");

  // Connect using HTTPS port 443
  if (!client.connect(host, 443)) {
    Serial.println("Connection failed");
    delay(5000);
    return;
  }

  Serial.println("Connected!");

  String url = "/sensor?temperature=" + String(temperature) +
               "&humidity=" + String(humidity) +
               "&deviceId=" + deviceId;

  Serial.println("Sending request:");
  Serial.println(url);

  client.print(String("GET ") + url + " HTTP/1.1\r\n" +
               "Host: " + host + "\r\n" +
               "Connection: close\r\n\r\n");

  // Read server response
  while (client.connected() || client.available()) {

    if (client.available()) {

      String line = client.readStringUntil('\n');
      Serial.println(line);
    }
  }

  Serial.println("Data stored ✅");
  Serial.println("------------------");

  delay(5000);
}