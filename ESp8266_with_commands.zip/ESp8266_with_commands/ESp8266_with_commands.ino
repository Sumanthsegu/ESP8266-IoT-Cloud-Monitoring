#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <DHT.h>

#define DHTPIN 2
#define DHTTYPE DHT11

DHT dht(DHTPIN, DHTTYPE);

// ======================
// WIFI
// ======================
const char* ssid = "SUMANTH";
const char* password = "asdfghjkl";

// ======================
// BACKEND
// ======================
const char* host = "iot-backend-atfp.onrender.com";

String deviceId = "esp001";

// ======================
// UART COMMAND BUFFER
// ======================
String cmd = "";

// ======================
// SENSOR VALUES
// ======================
float temperature = 0;
float humidity = 0;

// ======================
// SETUP
// ======================
void setup() {

  Serial.begin(115200);

  delay(1000);

  dht.begin();

  connectWiFi();

  Serial.println("ESP8266 Ready");
  Serial.println("Type Commands in PuTTY");
}

// ======================
// LOOP
// ======================
void loop() {

  // UART COMMAND CHECK
  checkUARTCommands();

  // WIFI RECONNECT
  if (WiFi.status() != WL_CONNECTED) {

    Serial.println("WiFi disconnected");

    connectWiFi();
  }

  // READ SENSOR
  readSensor();

  // SEND DATA TO BACKEND
  sendToBackend();

  for(int i=0; i<50; i++)
{
  checkUARTCommands();
  delay(100);
}
}

// ======================
// WIFI CONNECT FUNCTION
// ======================
void connectWiFi() {

  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);

    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");

  Serial.print("IP Address: ");

  Serial.println(WiFi.localIP());
}

// ======================
// SENSOR READ FUNCTION
// ======================
void readSensor() {

  temperature = dht.readTemperature();

  humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {

    Serial.println("Failed to read DHT11");

    return;
  }

  Serial.print("Temp: ");

  Serial.println(temperature);

  Serial.print("Humidity: ");

  Serial.println(humidity);
}

// ======================
// SEND DATA FUNCTION
// ======================
void sendToBackend() {

  WiFiClientSecure client;

  client.setInsecure();

  Serial.println("Connecting to backend...");

  if (!client.connect(host, 443)) {

    Serial.println("Connection failed");

    return;
  }

  Serial.println("Connected!");

  String url =
    "/sensor?temperature=" + String(temperature) +
    "&humidity=" + String(humidity) +
    "&deviceId=" + deviceId;

  Serial.println("Sending request:");

  Serial.println(url);

  client.print(String("GET ") + url + " HTTP/1.1\r\n" +
               "Host: " + host + "\r\n" +
               "Connection: close\r\n\r\n");

  while (client.connected() || client.available()) {

    if (client.available()) {

      String line = client.readStringUntil('\n');

      Serial.println(line);
    }
  }

  Serial.println("Data stored ✅");

  Serial.println("------------------");
}

// ======================
// UART COMMAND CHECK
// ======================
void checkUARTCommands() {

  while (Serial.available()) {

    char c = Serial.read();

    if (c == '\n' || c == '\r') {

      processCommand(cmd);

      cmd = "";
    }

    else {

      cmd += c;
    }
  }
}

// ======================
// COMMAND PROCESSOR
// ======================
void processCommand(String command) {

  command.trim();

  // AT TEST
  if (command == "AT") {

    Serial.println("OK");
  }

  // WIFI STATUS
  else if (command == "WIFI") {

    if (WiFi.status() == WL_CONNECTED)
      Serial.println("WiFi Connected");

    else
      Serial.println("WiFi Not Connected");
  }

  // IP ADDRESS
  else if (command == "IP") {

    Serial.println(WiFi.localIP());
  }

  // TEMPERATURE
  else if (command == "TEMP") {

    Serial.print("Temperature: ");

    Serial.println(temperature);
  }

  // HUMIDITY
  else if (command == "HUM") {

    Serial.print("Humidity: ");

    Serial.println(humidity);
  }

  // STATUS
  else if (command == "STATUS") {

    Serial.println("===== SYSTEM STATUS =====");

    Serial.print("WiFi: ");

    if (WiFi.status() == WL_CONNECTED)
      Serial.println("Connected");

    else
      Serial.println("Disconnected");

    Serial.print("Temperature: ");

    Serial.println(temperature);

    Serial.print("Humidity: ");

    Serial.println(humidity);

    Serial.println("=========================");
  }

  // MANUAL SEND
  else if (command == "SEND") {

    Serial.println("Manual Send Triggered");

    sendToBackend();
  }

  // RESET
  else if (command == "RESET") {

    Serial.println("Restarting...");

    ESP.restart();
  }

  // UNKNOWN COMMAND
  else {

    Serial.println("Unknown Command");
  }
}